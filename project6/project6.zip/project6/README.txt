Author: Nicholas Carnival 

1) Include names of all people who helped/collaborated as per the syllabus
STACKOVERFLOW! , Liam Warfield, Alejandro Meraz, Jordan Newport

2) Describe the challenges you encountered and how you surmounted them

3) What did you like/dislike about the assignment?

Liked: I like the understanding that I gained about ERD's from this assignment. I have 
used diagrams in other CS classes and never really fealt like I knew what they were, 
but after this assignment I have a newfound appreciation for ERD's.

Disliked: I disliked how long it took me. This was my own issue as grasping this
subject took me way longer than expected, but overall I learned alot about ERD's.

4) How long did you spend on this assignment?
I spent around 20 hours on this project. 
