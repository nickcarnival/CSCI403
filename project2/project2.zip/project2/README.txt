1) Collaborators
	Nicholas Carnival
2) Challenges: 
	SQL has some very strange syntax, but relatively simple commands.	
	SELECT FROM WHERE LIKE just doesnt roll off the tongue
3) Like/Dislike
	I liked the amount of queries that we had to do 
4) How long did you spend on this assignment?
	45 minutes.

