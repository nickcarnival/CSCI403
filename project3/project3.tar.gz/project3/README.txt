1) Include names of all people who helped/collaborated as per the syllabus
    Nicholas Carnival
2) Describe the challenges you encountered and how you surmounted them
    The only challenge I faced was setting the ustitle eqaul to the other title.
    I first created a sub query that returned the desired results from books1 and
    used that query to update all of the ustitles.
3) What did you like/dislike about the assignment?
    I enjoy using sql and being able to do the same thing multiple ways. 
4) How long did you spend on this assignment?
    I spent about 3 hours, mostly because I wanted to find other ways to do the same things.
