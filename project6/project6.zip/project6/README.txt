Author: Nicholas Carnival 

1) Include names of all people who helped/collaborated as per the syllabus
Liam Warfield, Alejandro Meraz
2) Describe the challenges you encountered and how you surmounted them
The most difficult part of this project was understanding what you are trying to do.
The cross reference table, memberships, had me confused for a long time. I heard that the
queries would be difficult, but I did not find them that difficult. Overall, 
understanding the ERD and how to translate that into SQL was by far the most difficult.
3) What did you like/dislike about the assignment?
Liked: I liked seeing how ERD's are useful. I have been in a lot of classes where we have to 
learnd a diagraming language, but never learn why. Using the ERD in this manner really
pushed the subject manner and forced me to have a deeper understanding.
Disliked: I disliked how long it took me. This was my own issue as grasping this
subject took me way longer than expected for some reason.
4) How long did you spend on this assignment?
I believe that I spent around 20 hours on this project. Most of this time was spent 
trying to understand exactly what I was trying to do. I spent a ton of time learning as
much as I could about ERD's. I now see why diagrams are important in programming.

